/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculategcdandlcm;

/**
 *
 * @author Dell-User
 */
import java.util.Scanner;

public class App{

    // Function to calculate GCD using Euclidean algorithm
    public static int calculateGCD(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    // Function to calculate LCM
    public static int calculateLCM(int a, int b) {
        return (a * b) / calculateGCD(a, b);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input first integer
        System.out.print("Enter the first integer: ");
        int num1 = scanner.nextInt();

        // Input second integer
        System.out.print("Enter the second integer: ");
        int num2 = scanner.nextInt();

        // Calculate GCD
        int gcd = calculateGCD(num1, num2);

        // Calculate LCM
        int lcm = calculateLCM(num1, num2);

        // Output the results
        System.out.println("Greatest Common Divisor (GCD): " + gcd);
        System.out.println("Least Common Multiple (LCM): " + lcm);
    }
}
