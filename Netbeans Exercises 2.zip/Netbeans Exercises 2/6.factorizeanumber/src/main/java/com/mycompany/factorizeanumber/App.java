/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.factorizeanumber;

/**
 *
 * @author Dell-User
 */
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a positive integer: ");
        int number = scanner.nextInt();
        
        System.out.println("Prime factors of " + number + " are:");
        printPrimeFactors(number);
    }
    
    public static void printPrimeFactors(int n) {
        if (n <= 1) {
            System.out.println("No prime factors for numbers less than 2.");
            return;
        }
        
        for (int i = 2; i <= n / i; i++) {
            while (n % i == 0) {
                System.out.println(i);
                n /= i;
            }
        }
        
        if (n > 1) {
            System.out.println(n);
        }
    }
}
