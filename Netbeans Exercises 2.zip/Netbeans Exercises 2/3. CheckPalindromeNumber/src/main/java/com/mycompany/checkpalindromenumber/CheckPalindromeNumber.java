/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.checkpalindromenumber;

import java.util.Scanner;

/**
 *
 * @author Dell-User
 */
public class CheckPalindromeNumber {

   public static boolean isPalindrome(int number) {
        int originalNumber = number;
        int reversedNumber = 0;
        
        while (number != 0) {
            int digit = number % 10;
            reversedNumber = reversedNumber * 10 + digit;
            number /= 10;
        }
        
        return originalNumber == reversedNumber;
    }

    public static void main(String[] args) {
       try (Scanner scanner = new Scanner(System.in)) {
           System.out.print("Enter an integer: ");
           int number = scanner.nextInt();
           
           if (isPalindrome(number)) {
               System.out.println(number + " is a palindrome number.");
           } else {
               System.out.println(number + " is not a palindrome number.");
           }
       }
    }
}
        
    

