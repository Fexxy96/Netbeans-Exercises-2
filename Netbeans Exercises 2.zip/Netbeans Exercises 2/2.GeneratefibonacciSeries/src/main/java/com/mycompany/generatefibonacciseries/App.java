/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.generatefibonacciseries;

/**
 *
 * @author Dell-User
 */
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of terms: ");
        int numberOfTerms = scanner.nextInt();

        System.out.println("Fibonacci Series up to " + numberOfTerms + " terms:");

        int firstTerm = 0, secondTerm = 1;
        for (int i = 1; i <= numberOfTerms; ++i) {
            System.out.print(firstTerm + " ");

            // Compute the next term
            int nextTerm = firstTerm + secondTerm;
            firstTerm = secondTerm;
            secondTerm = nextTerm;
        }
    }
}    
    

