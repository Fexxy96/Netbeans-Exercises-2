/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.displayasciivalueofacharacter;

/**
 *
 * @author Dell-User
 */
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);

        // Prompting user for input
        System.out.print("Enter a character: ");
        
        // Reading the input character
        char inputChar = scanner.next().charAt(0);

        // Casting the character to an integer will yield its ASCII value
        int asciiValue = (int) inputChar;

        // Displaying the ASCII value
        System.out.println("The ASCII value of " + inputChar + " is: " + asciiValue);

        scanner.close();
    }
}   