/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.computepowerofanumber;

/**
 *
 * @author Dell-User
 */
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
        
        // Ask user to enter base
        System.out.print("Enter the base: ");
        double base = scanner.nextDouble();
        
        // Ask user to enter exponent
        System.out.print("Enter the exponent: ");
        int exponent = scanner.nextInt();
        
        // Compute the power
        double result = calculatePower(base, exponent);
        
        // Display the result
        System.out.println(base + " raised to the power of " + exponent + " is: " + result);
        
        // Close the scanner
        scanner.close();
    }
    
    // Method to calculate power
    public static double calculatePower(double base, int exponent) {
        double result = 1;
        for (int i = 0; i < Math.abs(exponent); i++) {
            result *= base;
        }
        if (exponent < 0) {
            return 1 / result;
        } else {
            return result;
        }
    }
} 
